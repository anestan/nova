<?php
/**
 * 自定义结算完成订单详情页标题
 */
function order_received_title($title){
	if(is_order_received_page()){
		$title['title']='Oredr Checkout Detail';
		return $title;
	}
	return $title;
}
add_filter('document_title_parts', 'order_received_title', 10, 1);
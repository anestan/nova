<?php
/**
 * Astra Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Astra Child
 * @since 1.0.0
 */

/**
 * Define Constants
 */
define( 'CHILD_THEME_ASTRA_CHILD_VERSION', '1.0.0' );

/**
 * Enqueue styles
 */
function child_enqueue_styles() {

	wp_enqueue_style( 'astra-child-theme-css', get_stylesheet_directory_uri() . '/style.css', array('astra-theme-css'), CHILD_THEME_ASTRA_CHILD_VERSION, 'all' );

}

add_action( 'wp_enqueue_scripts', 'child_enqueue_styles', 15 );

// 添加谷歌标签管理器代码
// require get_stylesheet_directory() . "/hooks/add-google-tag-manager-code.php";

// 定义结算订单详情页标题
require get_stylesheet_directory() . "/hooks/custom-page-title.php";
// 重新排序结算字段
require get_stylesheet_directory() . "/hooks/checkout-fields-order.php";
// 定制数量输入框
require get_stylesheet_directory() . "/hooks/custom-quantity-input.php";
